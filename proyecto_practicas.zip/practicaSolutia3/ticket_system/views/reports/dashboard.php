<?php require_once BASE_PATH . 'ticket_system/views/partials/header.php'; ?>

<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center py-3">
        <h1 class="text-primary mb-0">
            <i class="fas fa-tachometer-alt me-2"></i>Dashboard de Tickets
        </h1>
        
    </div>

    <!-- Fila de KPIs -->
    <div class="row g-4 mb-4">
        <!-- Total Tickets -->
        <div class="col-xl-3 col-md-6">
            <div class="card border-primary kpi-card shadow-sm">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-uppercase text-muted fw-bold mb-2">Total Tickets</h6>
                            <h2 class="kpi-value mb-0"><?php echo $kpis['total_tickets']; ?></h2>
                        </div>
                        <div class="icon-circle bg-primary-light text-primary">
                            <i class="fas fa-ticket-alt fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Tickets Abiertos -->
        <div class="col-xl-3 col-md-6">
            <div class="card border-warning kpi-card shadow-sm">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-uppercase text-muted fw-bold mb-2">Tickets Abiertos</h6>
                            <h2 class="kpi-value mb-0"><?php echo $kpis['open_tickets']; ?></h2>
                        </div>
                        <div class="icon-circle bg-warning-light text-warning">
                            <i class="fas fa-exclamation-circle fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Tickets Cerrados -->
        <div class="col-xl-3 col-md-6">
            <div class="card border-success kpi-card shadow-sm">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-uppercase text-muted fw-bold mb-2">Tickets Cerrados</h6>
                            <h2 class="kpi-value mb-0"><?php echo $kpis['closed_tickets']; ?></h2>
                        </div>
                        <div class="icon-circle bg-success-light text-success">
                            <i class="fas fa-check-circle fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Tiempo Promedio -->
        <div class="col-xl-3 col-md-6">
            <div class="card border-info kpi-card shadow-sm">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-uppercase text-muted fw-bold mb-2">Tiempo Promedio</h6>
                            <h2 class="kpi-value mb-0"><?php echo $kpis['avg_resolution_time']; ?> <small class="fs-6">hrs</small></h2>
                        </div>
                        <div class="icon-circle bg-info-light text-info">
                            <i class="fas fa-stopwatch fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Fila de Gráficos -->
    <div class="row g-4 mb-4">
        <!-- Gráfico de estados -->
        <div class="col-xl-6">
            <div class="card shadow-sm h-100">
                <div class="card-header py-3">
                    <h5 class="mb-0">
                        <i class="fas fa-chart-pie me-2 text-primary"></i>
                        Tickets por Estado
                    </h5>
                </div>
                <div class="card-body pt-0">
                    <div class="chart-container">
                        <canvas id="statusChart" height="250"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <!-- Gráfico de prioridades -->
        <div class="col-xl-6">
            <div class="card shadow-sm h-100">
                <div class="card-header py-3">
                    <h5 class="mb-0">
                        <i class="fas fa-chart-bar me-2 text-primary"></i>
                        Tickets por Prioridad
                    </h5>
                </div>
                <div class="card-body pt-0">
                    <div class="chart-container">
                        <canvas id="priorityChart" height="250"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Gráfico de tendencias -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card shadow-sm">
                <div class="card-header py-3">
                    <h5 class="mb-0">
                        <i class="fas fa-chart-line me-2 text-primary"></i>
                        Tendencia de Tickets (Últimos 6 meses)
                    </h5>
                </div>
                <div class="card-body pt-0">
                    <div class="chart-container">
                        <canvas id="trendChart" height="300"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Acciones rápidas -->
    <div class="row">
        <div class="col-12">
            <div class="card shadow-sm">
                <div class="card-header py-3">
                    <h5 class="mb-0">
                        <i class="fas fa-bolt me-2 text-primary"></i>
                        Acciones Rápidas
                    </h5>
                </div>
                <div class="card-body">
                    <div class="d-flex flex-wrap gap-3 quick-actions">
                        <a href="index.php?controller=report&action=custom" class="btn btn-primary">
                            <i class="fas fa-file-alt me-2"></i> Informes Personalizados
                        </a>
                        <a href="index.php?controller=report&action=performance" class="btn btn-success">
                            <i class="fas fa-chart-line me-2"></i> Ver Gráficos Avanzados
                        </a>
                        <a href="index.php?controller=ticket&action=create" class="btn btn-warning">
                            <i class="fas fa-plus-circle me-2"></i> Crear Nuevo Ticket
                        </a>
                        <a href="index.php?controller=user&action=index" class="btn btn-info">
                            <i class="fas fa-users me-2"></i> Gestionar Usuarios
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<?php require_once BASE_PATH . 'ticket_system/views/partials/footer.php'; ?>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
    $(document).ready(function() {
        // Script para el modo oscuro/claro
        const themeButton = document.getElementById('theme-button');
        const body = document.body;
        const icon = themeButton.querySelector('i');

        if (localStorage.getItem('darkMode') === 'true') {
            enableDarkMode();
        }

        themeButton.addEventListener('click', toggleDarkMode);

        function toggleDarkMode() {
            if (body.classList.contains('dark-mode')) {
                disableDarkMode();
            } else {
                enableDarkMode();
            }
        }

        function enableDarkMode() {
            body.classList.add('dark-mode');
            icon.classList.replace('fa-moon', 'fa-sun');
            themeButton.innerHTML = '<i class="fas fa-sun me-2"></i> Modo Claro';
            localStorage.setItem('darkMode', 'true');
        }

        function disableDarkMode() {
            body.classList.remove('dark-mode');
            icon.classList.replace('fa-sun', 'fa-moon');
            themeButton.innerHTML = '<i class="fas fa-moon me-2"></i> Modo Oscuro';
            localStorage.setItem('darkMode', 'false');
        }

        // Inicializar DataTable
        $('#usersTable').DataTable({
            language: {
                url: '//cdn.datatables.net/plug-ins/1.10.24/i18n/Spanish.json'
            },
            responsive: true
        });
    });

        // Datos para los gráficos
        const statusLabels = [<?php 
            if (isset($kpis['tickets_by_status']) && is_array($kpis['tickets_by_status'])) {
                foreach ($kpis['tickets_by_status'] as $status) {
                    $statusLabel = '';
                    switch ($status['status']) {
                        case 'open': $statusLabel = 'Abierto'; break;
                        case 'in_progress': $statusLabel = 'En Progreso'; break;
                        case 'resolved': $statusLabel = 'Resuelto'; break;
                        case 'closed': $statusLabel = 'Cerrado'; break;
                        default: $statusLabel = $status['status']; break;
                    }
                    echo "'" . $statusLabel . "',";
                }
            } else {
                echo "'Abierto','En Progreso','Resuelto','Cerrado'";
            }
        ?>];
        
        const statusValues = [<?php 
            if (isset($kpis['tickets_by_status']) && is_array($kpis['tickets_by_status'])) {
                foreach ($kpis['tickets_by_status'] as $status) {
                    echo ($status['total'] ?? 0) . ",";
                }
            } else {
                echo "0,0,0,0";
            }
        ?>];
        
        const priorityLabels = [<?php 
            if (isset($priorityStats) && is_array($priorityStats)) {
                foreach ($priorityStats as $p) {
                    echo "'" . ucfirst($p['priority'] ?? 'Desconocido') . "',";
                }
            } else {
                echo "'Baja','Media','Alta','Urgente'";
            }
        ?>];
        
        const priorityValues = [<?php 
            if (isset($priorityStats) && is_array($priorityStats)) {
                foreach ($priorityStats as $p) {
                    echo ($p['total'] ?? 0) . ",";
                }
            } else {
                echo "0,0,0,0";
            }
        ?>];
        
        const trendLabels = [<?php 
            if (isset($trends) && is_array($trends)) {
                foreach ($trends as $trend) {
                    echo "'" . ($trend['period'] ?? '') . "',";
                }
            }
        ?>];
        
        const trendTickets = [<?php 
            if (isset($trends) && is_array($trends)) {
                foreach ($trends as $trend) {
                    echo ($trend['total_tickets'] ?? 0) . ",";
                }
            }
        ?>];
        
        const trendClosed = [<?php 
            if (isset($trends) && is_array($trends)) {
                foreach ($trends as $trend) {
                    echo ($trend['closed_tickets'] ?? 0) . ",";
                }
            }
        ?>];
        
        // Crear gráficos
        window.onload = function() {
            // Gráfico de estados
            if (statusLabels.length > 0) {
                new Chart(document.getElementById('statusChart'), {
                    type: 'pie',
                    data: {
                        labels: statusLabels,
                        datasets: [{
                            label: 'Tickets por Estado',
                            data: statusValues,
                            backgroundColor: [
                                'rgba(255, 206, 86, 0.7)', // Amarillo para Abierto
                                'rgba(54, 162, 235, 0.7)', // Azul para En Progreso
                                'rgba(75, 192, 192, 0.7)', // Verde claro para Resuelto
                                'rgba(153, 102, 255, 0.7)' // Morado para Cerrado
                            ]
                        }]
                    },
                    options: {
                        responsive: true,
                        plugins: {
                            legend: {
                                position: 'right',
                            },
                            title: {
                                display: true,
                                text: 'Distribución por Estado'
                            }
                        }
                    }
                });
            }
            
            // Gráfico de prioridades
            if (priorityLabels.length > 0) {
                new Chart(document.getElementById('priorityChart'), {
                    type: 'bar',
                    data: {
                        labels: priorityLabels,
                        datasets: [{
                            label: 'Tickets por Prioridad',
                            data: priorityValues,
                            backgroundColor: [
                                'rgba(75, 192, 192, 0.7)',
                                'rgba(255, 206, 86, 0.7)',
                                'rgba(255, 159, 64, 0.7)',
                                'rgba(255, 99, 132, 0.7)'
                            ]
                        }]
                    },
                    options: {
                        responsive: true,
                        plugins: {
                            legend: {
                                display: false
                            },
                            title: {
                                display: true,
                                text: 'Distribución por Prioridad'
                            }
                        }
                    }
                });
            }
            
            // Gráfico de tendencias
            if (trendLabels.length > 0) {
                new Chart(document.getElementById('trendChart'), {
                    type: 'line',
                    data: {
                        labels: trendLabels,
                        datasets: [{
                            label: 'Total Tickets',
                            data: trendTickets,
                            borderColor: 'rgba(54, 162, 235, 1)',
                            backgroundColor: 'rgba(54, 162, 235, 0.2)',
                            fill: true
                        }, {
                            label: 'Tickets Cerrados',
                            data: trendClosed,
                            borderColor: 'rgba(75, 192, 192, 1)',
                            backgroundColor: 'rgba(75, 192, 192, 0.2)',
                            fill: true
                        }]
                    },
                    options: {
                        responsive: true,
                        plugins: {
                            title: {
                                display: true,
                                text: 'Tendencia de Tickets'
                            }
                        },
                        scales: {
                            y: {
                                beginAtZero: true
                            }
                        }
                    }
                });
            }
        };
    </script>
</body>
</html>
