<footer class="bg-dark text-white text-center py-3 mt-5">
        <div class="container">
            <p class="mb-0">Sistema de Tickets &copy; <?php echo date('Y'); ?></p>
        </div>
    </footer>

    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Script para el modo oscuro/claro -->
    <script src="<?php echo BASE_PATH; ?>ticket_system/js/dark-mode.js"></script>
</body>
</html>